package com.fastcampus.javaallinone.project3.mycontact;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class MycontactApplicationTests {

  @Test
  public void contextLoads() {
  }

}
