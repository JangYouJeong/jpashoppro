package jpabook.jpashop.domain;

public class DeliveryStatus {
    public static DeliveryStatus READY;
    public static DeliveryStatus COMP;
}
